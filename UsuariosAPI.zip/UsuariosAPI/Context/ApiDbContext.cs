﻿using Microsoft.EntityFrameworkCore;
using UsuariosAPI.Models;

namespace UsuariosAPI.Context
{
    public class ApiDbContext : DbContext
    {
        public DbSet<Usuario> Usuario { get; set; }

        public ApiDbContext(DbContextOptions<ApiDbContext> options)
        : base(options)
        {
        }
    }
}
